#!/usr/bin/perl 

open(INFILE, $ARGV[0]) || die "Error: can't open file.\n"; 
@result = <INFILE>;
close(INFILE);

$p_num = 0;
$flag = 1;
while ($flag == 1) {
	$flag = 0;
	$p_num++;
	foreach $line (@result) {
		if ( $line =~ /\(= \(coord p$p_num/ ) {
			$flag = 1;
		}
	}
}
$p_num--;

$r_num = 0;
$flag = 1;
while ($flag == 1) {
	$flag = 0;
	$r_num++;
	foreach $line (@result) {
		if ( $line =~ /\(= \(dv p1 r$r_num -1\) [\d]+\)/ ) {
			$flag = 1;
		}
	}
}
$r_num--;

$ph_num = 1;
$flag = 1;
while ($flag == 1) {
	$flag = 0;
	foreach $line (@result) {
		if ( $line =~ /\(= \(coord p\d+ $ph_num+\) \d+\)/ ) {
			$flag = 1;
		}
	}
	$ph_num++;
}
$ph_num--;

$i = 0;
$flag = -1;
foreach $line (@result) {
	if ( $line =~ /\(= phase (\d+)\)/ ) {
		$phase = $1;
	} elsif ( $line =~ /\(= \(dv p\d+ r\d+ 0\) \d+\)/ ) {
	} elsif ( $line =~ /\(= \(dv p(\d+) r(\d+) -1\) ([\d])+\)/ ) {
		$dv[$1][$2] = $3;
	} elsif ( $line =~ /\(([a-zA-Z][a-zA-Z0-9]*) p1 r1 0\) (\d+|true|false)\)/ ) {
		$var_name[$i++] = $1;
		$var{$1}[1][1] = $2;
	} elsif ( $line =~ /\(([a-zA-Z][a-zA-Z0-9]*) p(\d+) r(\d+) 0\) (\d+|true|false)\)/ ) {
		$var{$1}[$2][$3] = $4;
	} elsif ( $line =~ /\(= \(coord p(\d+) (\d)+\) (\d+)\)/ ) {
		$flag = 1;
		$coord[$1][$2] = $3;
	} elsif ( $line =~ /\(= \(coord p(\d+)\) (\d+)\)/ ) {
		$flag = 0;
		$coord[$1] = $2;
	} elsif ( $line =~ /\(= \(rcv p(\d+) r(\d+) (\d+)\) \(mk-tuple ([0|1])/ ) {
		$ho[$1][$2][$3] = $4;
	}
}

$curr_phase = $phase;
for ($round = 2; $round <= $r_num + 1; $round++) {
	if ($round == 2) {
		print "<Initial configuration>\n";
		printf("               |",);
		for ($i = 1; $i <= $p_num; $i++) {
			printf("%-6s|", "p$i");
		}
		print "\n";
		print "---------------|";
		for ($i = 1; $i <= $p_num; $i++) {
			printf("------|");
		}
		print "\n";
		foreach $curr_name (@var_name) {
			printf("%-15s|", $curr_name);
			for ($i = 1; $i <= $p_num; $i++) {
				printf("%-6s|", $var{$curr_name}[$i][1]);
			}
			print "\n";
		}
		print "\n";
	}
	if (($round - 1)%($r_num/$ph_num) == 1) {
		print "================";
		for ($i = 1; $i <= $p_num; $i++) {
			printf("=======");
		}
		print "\n";
		print "PHASE $curr_phase\n";
		if (flag != -1) {
			for ($i = 1; $i <= $p_num; $i++) {
				printf("Coord(p%d, %d) = p%d\n", $i, $curr_phase, $flag == 1 ? $coord[$i][$curr_phase] : $coord[$i]);
			}
		}
		print "\n";
		print "================";
		for ($i = 1; $i <= $p_num; $i++) {
			printf("=======");
		}
		print "\n";
		$curr_phase++;
	}

	print "****************";
	for ($i = 1; $i <= $p_num; $i++) {
		printf("*******");
	}
	print "\n";
	printf("ROUND %d\n", $round - 1);
	for ($i = 1; $i <= $p_num; $i++) {
		printf("HO(p%d, %d) = {", $i, $round - 1);
		$flag2 = 0;
		for ($j = 1; $j <= $p_num; $j++) {
			if ($ho[$i][$round - 1][$j] == 1) {
				printf("%sp%d", $flag2 == 1 ? " ," : "", $j);
				$flag2 = 1;
			} 
		}
		print "}\n";
	}
	for ($i = 1; $i <= $p_num; $i++) {
		if ($dv[$i][$round-1] != 0) {
			print "p$i decides $dv[$i][$round-1]\n";
		}
	}
	print "****************";
	for ($i = 1; $i <= $p_num; $i++) {
		printf("*******");
	}
	print "\n\n";

	printf("               |",);
	for ($i = 1; $i <= $p_num; $i++) {
		printf("%-6s|", "p$i");
	}
	print "\n";
	print "---------------|";
	for ($i = 1; $i <= $p_num; $i++) {
		printf("------|");
	}
	print "\n";
	foreach $curr_name (@var_name) {
		printf("%-15s|", $curr_name);
		for ($i = 1; $i <= $p_num; $i++) {
			printf("%-6s|", $var{$curr_name}[$i][$round]);
		}
		print "\n";
	}
	print "\n";
}
