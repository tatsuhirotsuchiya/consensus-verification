#include "translator.h"

FILE *infile = NULL; // Input file
char *outbuf = NULL; // Output buffer
FILE *outfile = NULL; // Output file
char outfilename[FNAME_LEN] = ""; // Output file name
char *guard = NULL; // Guard condition
char *assertion = NULL; // Assertions
char *assumption = NULL; // Assumptions
int agr_mode = 0; // Agreement mode (-a)
int uni_mode = 0; // Univalence mode (-u)
int inv_mode = 0; // Invariant mode (-i)
int trace_mode = 0; // Trace mode (-t)

int main(int argc, char *argv[]) {
	int len, result;
	extern char *optarg;
	extern int optind;
	char *check;
	char *command;
	char cmd[512] = "", *c;

	command = argv[0];

	// Option
	while ((result = getopt(argc, argv, "n:auip:t")) != -1) {
		switch (result) {
		case 'n':
			n = (int) strtol(optarg, &check, 10);
			if (*check != '\0' || n < 3 || n > MAX_N) { // Check <num>
				error("Missing argument for option '-n <num>'.");
			}
			break;
		case 'a':
			agr_mode = 1;
			break;
		case 'u':
			uni_mode = 1;
			break;
		case 'i':
			inv_mode = 1;
			break;
		case 'p':
			phase = (int) strtol(optarg, &check, 10);
			if (*check != '\0' || phase < 1 || phase > MAX_PHASE) { // Check <num>
				error("Missing argument for option '-p <num>'.");
			}
			break;
		case 't':
			trace_mode = 1;
			break;
		case '?': // unknown option
			error("invalid option.");
			break;
		}
	}
	argc -= optind;
	argv += optind;

	// -t
	if (trace_mode) {
		if (argc == 1) {
			strncpy(cmd, command, sizeof(cmd) - 1);
			for (c = cmd + strlen(cmd) - 1; *c != '/' && c > cmd; c = c - 1)
				;
			c = (c == cmd) ? cmd : c + 1;
			strncpy(c, "gen_trace.pl ", sizeof(cmd) - strlen(cmd) + strlen(c)
					- 1);
			strncat(cmd, argv[argc - 1], sizeof(cmd) - strlen(cmd) - 1);
			system(cmd);
			exit(0);
		} else {
			fprintf(stderr, "Usage: translator -t infile\n");
			exit(1);
		}
	}

	if (argc != 2) { // Check number of arguments
		usage();
		exit(1);
	}

	if (agr_mode + uni_mode + inv_mode > 1) {
		error("-a, -u, and -i cannot be used at the same time.");
	} else if (phase > 1 && agr_mode + uni_mode + inv_mode == 1) {
		error("-p and -a (-u, -i) cannot be used at the same time.");
	}

	// Whether file extension is 'alg'
	len = strlen(argv[argc - 2]);
	if ((len < 5) || (argv[argc - 2][len - 4] != '.') || (argv[argc - 2][len
			- 3] != 'a') || (argv[argc - 2][len - 2] != 'l')
			|| (argv[argc - 2][len - 1] != 'g')) {
		error("file extension of an input file must be 'alg'.");
	}

	// Open files
	infile = fopen(argv[argc - 2], "r");
	outfile = tmpfile();
	if ((!infile) || (!outfile)) error("could not open file.");

	yyin = infile;
	rewind(yyin);
	yyrestart(yyin);
	prs_alg(); /* Parse */
	fclose(yyin);

	infile = outfile;
	outfile = NULL;
	yyin = infile;
	rewind(yyin);
	yyrestart(yyin);

	asprintf(&guard, "true");
	asprintf(&assertion, "    true\n");
	asprintf(&assumption, "    true\n");

	gen_alg(); /* Encode */
	fprintf(stdout, "Completed\n");

	fclose(infile);
	free(guard);
	free(assertion);
	free(assumption);

	// Write 'outbuf' into 'outfile'
	strcpy(outfilename, argv[argc - 1]);
	outfile = fopen(outfilename, "w");
	if (!outfile) error("could not open file.");
	fprintf(outfile, "%s", outbuf);
	fprintf(outfile, "(check)\n");
	fclose(outfile);
	free(outbuf);

	return 0;
}
