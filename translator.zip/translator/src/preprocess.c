#include "translator.h"

#define NOCHECK -1
#define NONE -9999

VTYPE *v_list = NULL; // Pointer to the list of variables
int n = 3; // Number of processes (default is 3)
int round_count = 0; // Number of rounds
int phase = 1; // Number of modeled phases
int coord_flag; // enable coordinators
int sendCoord = 0; // Coodinator's id becomes a message in current parsing round : 1
int deapth_of_nest = 0;

// Get new token
int next_tokn(FILE *fp, int kind);

// Functions relate to parsing
void prs_alg();
void prs_v_dec();
void prs_round_rep();
void prs_round();
void prs_s_part();
void prs_t_part();
void prs_inv();
void prs_uni();
void prs_stmt_rep(FILE *dest, int mode);
void prs_stmt(FILE *dest, int mode);
enum TYPE prs_expr(FILE *fp, int mode);
enum TYPE prs_and_expr(FILE *fp, int mode);
enum TYPE prs_equality_expr(FILE *fp, int mode);
enum TYPE prs_relational_expr(FILE *fp, int mode);
enum TYPE prs_simple_expr(FILE *fp, int mode);
enum TYPE prs_term(FILE *fp, int mode);
enum TYPE prs_factor(FILE *fp, int mode);

// Token judgment functions
int isEqualityOperator(enum SYMBOL kind);
int isRelationalOperator(enum SYMBOL kind);
int isAdditiveOperator(enum SYMBOL kind);
int isMultiplicativeOperator(enum SYMBOL kind);

// Check whether identifier is already reserved or not
int isReservedKeyword(const char *keyword);

// Functions to operate the variable table
void insert_variable(char *name, enum TYPE type, int value, int send,
		int hidden, int assign_count, int *ptr, int other_field);
VTYPE *search_variable(char *name);

void prs_alg() {
	VTYPE *v;

	next_tokn(outfile, SALGORITHM);
	next_tokn(outfile, SIDENTIFIER);
	next_tokn(outfile, SSEMICOLON);
	prs_v_dec();
	prs_round_rep();
	if (token.kind == SINVARIANT) {
		prs_inv();
		next_tokn(outfile, NONE);
	}
	if (token.kind == SUNIVALENCE) {
		prs_uni();
	}
	if (next_tokn(outfile, NONE)) syntax_error("syntax error.");

	if (coord_flag) {
		for (v = v_list; v != NULL; v = v->next) {
			if (v->isHidden || v->type == TBOOL) continue;
			v->other_field++;
		}
	}
}

void prs_v_dec() {
	char name[NAME_LEN];
	enum TYPE type;
	int value = 0, hidden = 0, count = 1;
	int *ptr = NULL;

	next_tokn(outfile, SVARIABLE);
	next_tokn(outfile, NOCHECK);
	do {
		if (token.kind == SHIDDEN) {
			hidden = 1;
			next_tokn(outfile, NOCHECK);
		}
		switch (token.kind) {
		case SV:
			type = TV;
			break;
		case SVD:
			type = TVD;
			break;
		case STS:
			type = TTS;
			break;
		case SVARRAY:
			if (!hidden) semantic_error("VArray must be declared as hidden.");
			type = TVARRAY;
			break;
		case STSARRAY:
			if (!hidden) semantic_error("TSArray must be declared as hidden.");
			type = TTSARRAY;
			break;
		case SBOOL:
			type = TBOOL;
			break;
		case SINT:
			if (!hidden) semantic_error("int must be declared as hidden.");
			type = TINT;
			break;
		case SINTARRAY:
			if (!hidden) semantic_error("intArray must be declared as hidden.");
			type = TINTARRAY;
			break;
		default:
			syntax_error("syntax error.");
		};
		do {
			next_tokn(outfile, SIDENTIFIER);
			strcpy(name, token.id);
			if (isReservedKeyword(name)) semantic_error(
					"already reserved name.");
			next_tokn(outfile, NOCHECK);
			if (token.kind == SASSIGN) { // initialization of variable
				next_tokn(outfile, NOCHECK);
				switch (token.kind) {
				case SQUESTION:
					if (type != TVD) semantic_error(
							"cannot be initialized with ?.");
					value = UNDEF;
					break;
				case SFALSE:
					if (type != TBOOL) semantic_error(
							"cannot be initialized with false.");
					value = FALSE;
					break;
				case STRUE:
					if (type != TBOOL) semantic_error(
							"cannot be initialized with true.");
					value = TRUE;
					break;
				case SNUM:
					if (type != TTS) semantic_error(
							"cannot be initialized with integer.");
					value = atoi(token.id);
					break;
				case SVP:
					if (type != TV && type != TVD) semantic_error(
							"cannot be initialized with Vp.");
					value = ANY_V;
					break;
				default:
					syntax_error("syntax error.");
				}
				next_tokn(outfile, NOCHECK);
			} else value = UNINI; // no initialization
			if (type == TINTARRAY || type == TVARRAY || type == TTSARRAY) {
				ptr = (int *) calloc(n, sizeof(int));
				if (ptr == NULL) error("memory allocation error.");
			};
			if (search_variable(name) != NULL) semantic_error(
					"already declared name.");
			if (!hidden && type != TBOOL) // sendable variables
				insert_variable(name, type, value, 0, hidden, 0, ptr, ++count);
			else // unsendable variables
				insert_variable(name, type, value, 0, hidden, 0, ptr, 0);
		} while (token.kind == SCOMMA);
		if (token.kind != SSEMICOLON) syntax_error("syntax error.");
		next_tokn(outfile, NOCHECK);
	} while (token.kind != SROUND);
}

void prs_round_rep() {
	do {
		prs_round();
		next_tokn(outfile, SSEMICOLON);
		round_count++;
	} while (next_tokn(outfile, NONE) && token.kind == SROUND);
	round_count *= phase;
}

void prs_round() {
	VTYPE *temp;

	if (token.kind != SROUND) syntax_error("syntax error.");
	next_tokn(outfile, SLBRACE);
	next_tokn(outfile, SSP);
	prs_s_part();
	if (token.kind != SSEMICOLON) syntax_error("syntax error.");
	next_tokn(outfile, STP);
	prs_t_part();
	if (token.kind != SRBRACE) syntax_error("syntax error.");
	for (temp = v_list; temp != NULL; temp = temp->next)
		temp->isMessage = 0; // reset message flag
}

void prs_s_part() {
	int if_flag;
	enum SYMBOL dest;
	VTYPE *v;

	if_flag = 0;
	sendCoord = 0;
	next_tokn(outfile, NOCHECK);
	if (token.kind == SIF) {
		if_flag = 1;
		next_tokn(outfile, SLPAREN);
		if (prs_expr(outfile, SEND_MODE) != TBOOL) semantic_error(
				"type mismatch.");
		if (token.kind != SRPAREN) syntax_error("syntax error.");
		next_tokn(outfile, NOCHECK);
	}
	if (token.kind != SSEND) syntax_error("syntax error.");
	next_tokn(outfile, SLPAREN);
	next_tokn(outfile, SLESS);
	next_tokn(outfile, NOCHECK);
	if (token.kind != SACK) { // send message
		do {
			if (token.kind != SIDENTIFIER && token.kind != SCOORD) syntax_error(
					"syntax error.");
			if (token.kind == SCOORD)
				sendCoord = 1;
			else {
				if ((v = search_variable(token.id)) == NULL || v->isHidden
						|| v->type == TBOOL) {
					semantic_error("cannot be used as message.");
				} else v->isMessage = 1; // the variable is used as message
			}
			next_tokn(outfile, NOCHECK);
			if (token.kind != SCOMMA) break;
		} while (next_tokn(outfile, NOCHECK));
	} else { // send only Ack
		next_tokn(outfile, NOCHECK);
	};
	if (token.kind != SGREAT) syntax_error("syntax error.");
	next_tokn(outfile, SCOMMA);
	next_tokn(outfile, NOCHECK);
	switch (token.kind) {
	case SALL:
	case SCOORD:
		dest = token.kind;
		break;
	default:
		syntax_error("syntax error.");
	}
	next_tokn(outfile, SRPAREN);
	next_tokn(outfile, NOCHECK);
	if (if_flag && token.kind == SELSE) {
		next_tokn(outfile, SSEND);
		next_tokn(outfile, SLPAREN);
		next_tokn(outfile, SLESS);
		next_tokn(outfile, NOCHECK);
		if (token.kind != SACK) { // send message
			do {
				if (token.kind != SIDENTIFIER && token.kind != SCOORD) syntax_error(
						"syntax error.");
				if (token.kind == SCOORD)
					sendCoord = 2;
				else {
					if ((v = search_variable(token.id)) == NULL || v->isHidden
							|| v->type == TBOOL) {
						semantic_error("cannot be used as message.");
					} else {
						v->isMessage = 2; // the variable is used as message in else block
					}
				}
				next_tokn(outfile, NOCHECK);
				if (token.kind != SCOMMA) break;
			} while (next_tokn(outfile, NOCHECK));
		} else { // send only Ack
			next_tokn(outfile, NOCHECK);
		};
		if (token.kind != SGREAT) syntax_error("syntax error.");
		next_tokn(outfile, SCOMMA);
		next_tokn(outfile, NOCHECK);
		switch (token.kind) {
		case SALL:
		case SCOORD:
			if (token.kind != dest) semantic_error("inconsistent destination.");
			break;
		default:
			syntax_error("syntax error.");
		}
		next_tokn(outfile, SRPAREN);
		next_tokn(outfile, NOCHECK);
	} else if (!if_flag && token.kind == SELSE) syntax_error("syntax error.");
}

void prs_t_part() {
	prs_stmt_rep(outfile, NORMAL_MODE);
}

void prs_inv() {
	next_tokn(outfile, SLBRACE);
	prs_stmt_rep(outfile, INV_MODE);
	if (token.kind != SRBRACE) syntax_error("syntax error.");
	next_tokn(outfile, SSEMICOLON);
}

void prs_uni() {
	next_tokn(outfile, SLBRACE);
	prs_stmt_rep(outfile, UNI_MODE);
	if (token.kind != SRBRACE) syntax_error("syntax error.");
	next_tokn(outfile, SSEMICOLON);
}

void prs_stmt_rep(FILE *dest, int mode) {
	next_tokn(dest, NOCHECK);
	do {
		prs_stmt(dest, mode);
		if (token.kind != SSEMICOLON) syntax_error("syntax error.");
		next_tokn(dest, NOCHECK);
	} while (token.kind != SRBRACE);
}

void prs_stmt(FILE *dest, int mode) {
	VTYPE *v;
	enum TYPE type1, type2;
	int i;
	int init_value, final_value;
	int start_line;
	FILE *before_for_fp = NULL, *in_for_fp = NULL, *after_for_fp = NULL;

	switch (token.kind) {
	case SIDENTIFIER: /* assignment */
		if ((v = search_variable(token.id)) == NULL) semantic_error(
				"undeclared variable.");
		if (v->type != TINTARRAY && v->type != TVARRAY && v->type != TTSARRAY) { // normal variable
			if ((mode == INV_MODE || mode == UNI_MODE) && !v->isHidden) semantic_error(
					"process variable cannot be assigned here.");
			if (v->other_field < 0) semantic_error(
					"loop counter cannot be updated here.");
			type1 = v->type;
		} else { // array variable
			next_tokn(dest, SLBRACKET);
			if (prs_expr(dest, mode) != TINT) semantic_error("type mismatch.");
			if (token.kind != SRBRACKET) syntax_error("syntax error.");
			switch (v->type) {
			case TINTARRAY:
				type1 = TINT;
				break;
			case TVARRAY:
				type1 = TV;
				break;
			case TTSARRAY:
				type1 = TTS;
				break;
			default:
				semantic_error("type mismatch.");
			}
		}
		next_tokn(dest, SASSIGN);
		type2 = prs_expr(dest, mode);
		if (type1 == TV && type2 == TVD && !strcmp(token.id, "?")) semantic_error(
				"type mismatch.");
		if (!(((type1 == TV || type1 == TVD) && (type2 == TV || type2 == TVD
				|| type2 == TNULL /*|| type2 == TEMPTY*/)) || (type1 == TTS
				&& (type2 == TTS || type2 == TNULL /*|| type2 == TEMPTY*/))
				|| (type1 == type2))) semantic_error("type mismatch.");
		break;
	case SDECIDE: /* decision statement */
		if (mode == INV_MODE || mode == UNI_MODE) semantic_error(
				"DECIDE cannot be used here.");
		next_tokn(dest, SLPAREN);
		type1 = prs_expr(dest, mode);
		if (token.kind != SRPAREN) syntax_error("syntax error.");
		next_tokn(dest, NOCHECK);
		if (type1 != TV && type1 != TVD) semantic_error("type mismatch.");
		break;
	case SFOR: /* for loop */
		/* preprocessing */
		deapth_of_nest++;
		if (!gettokn() || token.kind != SLBRACKET) syntax_error("syntax error.");
		if (!gettokn() || token.kind != SIDENTIFIER) syntax_error(
				"syntax error.");
		if ((v = search_variable(token.id)) == NULL) semantic_error(
				"undeclared variable.");
		if (v->type != TINT) semantic_error("roop counter must be integer.");
		if (v->other_field < 0) semantic_error(
				"already used as a roop counter.");
		v->other_field = -1; /* use 'v' as a loop counter */
		if (!gettokn() || token.kind != SASSIGN) syntax_error("syntax error.");
		if ((init_value = calc_expr()) < 1) semantic_error(
				"index is out of range.");
		if (token.kind != STO) syntax_error("syntax error.");
		if ((final_value = calc_expr()) > n) semantic_error(
				"index is out of range.");
		if (token.kind != SRBRACKET) syntax_error("syntax error.");
		before_for_fp = yyin;

		/* copy block statement of for loop to tmp_fp */
		in_for_fp = open_tmpfile();
		next_tokn(in_for_fp, NOCHECK);
		start_line = line_num;
		i = 0;
		do {
			i = (token.kind == SLBRACE) ? i + 1 : (token.kind == SRBRACE) ? i
					- 1 : i;
			if (i == 0) {
				while (token.kind != SSEMICOLON)
					next_tokn(in_for_fp, NOCHECK);
				break;
			}
		} while (next_tokn(in_for_fp, NOCHECK));

		/* copy after block statement of for loop to tmp_fp2 */
		after_for_fp = open_tmpfile();
		while (next_tokn(after_for_fp, NONE))
			;

		/* extract block statement (final_value - init_value + 1) times */
		fprintf(dest, "(%s) {\n", v->name);
		for (i = init_value; i <= final_value; i++) {
			v->value = i;
			fprintf(dest, "%s = %d;\n", v->name, i);
			yyin = in_for_fp;
			rewind(yyin);
			yyrestart(yyin);
			line_num = start_line;
			next_tokn(dest, NOCHECK);
			prs_stmt(dest, mode);
			fprintf(dest, "\n");
			if (yyin != in_for_fp) fclose(yyin);
		}
		fprintf(dest, "};");

		/* post processing */
		deapth_of_nest--;
		v->other_field = 0;
		fclose(in_for_fp);
		if (!deapth_of_nest) fclose(before_for_fp);
		yyin = after_for_fp;
		rewind(yyin);
		yyrestart(yyin);
		break;
	case SIF: /* if statement */
		next_tokn(dest, SLPAREN);
		if (prs_expr(dest, mode) != TBOOL) semantic_error("type mismatch.");
		if (token.kind != SRPAREN) syntax_error("syntax error.");
		next_tokn(dest, NOCHECK);
		prs_stmt(dest, mode);
		if (token.kind == SELSE) {
			next_tokn(dest, NOCHECK);
			prs_stmt(dest, mode);
		}
		break;
	case SASSUME: /* assume statement */
		if (mode != INV_MODE) semantic_error("assume cannot be used here.");
		next_tokn(dest, SLPAREN);
		type1 = prs_expr(dest, mode);
		if (type1 != TBOOL) semantic_error("type mismatch.");
		if (token.kind != SRPAREN) syntax_error("syntax error.");
		next_tokn(dest, NOCHECK);
		break;
	case SASSERT: /* assert statement */
		if (mode != UNI_MODE) semantic_error("assert cannot be used here.");
		next_tokn(dest, SLPAREN);
		type1 = prs_expr(dest, mode);
		if (type1 != TBOOL) semantic_error("type mismatch.");
		if (token.kind != SRPAREN) syntax_error("syntax error.");
		next_tokn(dest, NOCHECK);
		break;
	case SLBRACE: /* block statement */
		prs_stmt_rep(dest, mode);
		if (token.kind != SRBRACE) syntax_error("syntax error.");
		next_tokn(dest, NOCHECK);
		break;
	default:
		syntax_error("syntax error.");
	}
}

enum TYPE prs_expr(FILE *fp, int mode) {
	enum TYPE type1, type2;

	type1 = prs_and_expr(fp, mode);
	while (token.kind == SOR) {
		type2 = prs_and_expr(fp, mode);
		if (type1 != type2 || type1 != TBOOL) semantic_error("type mismatch.");
	};
	return type1;
}

enum TYPE prs_and_expr(FILE *fp, int mode) {
	enum TYPE type1, type2;

	type1 = prs_equality_expr(fp, mode);
	while (token.kind == SAND) {
		type2 = prs_equality_expr(fp, mode);
		if (type1 != type2 || type1 != TBOOL) semantic_error("type mismatch.");
	};
	return type1;
}

enum TYPE prs_equality_expr(FILE *fp, int mode) {
	enum TYPE type1, type2;

	type1 = prs_relational_expr(fp, mode);
	if (isEqualityOperator(token.kind)) {
		type2 = prs_relational_expr(fp, mode);
		if (!(type1 == type2 || ((type1 == TV || type1 == TVD || type1 == TNULL
				|| type1 == TEMPTY) && (type2 == TV || type2 == TVD || type2
				== TNULL || type2 == TEMPTY)) || ((type1 == TTS || type1
				== TNULL || type1 == TEMPTY || type1 == TINT) && (type2 == TTS
				|| type2 == TNULL || type2 == TEMPTY || type2 == TINT)))) semantic_error(
				"type mismatch.");
		type1 = TBOOL;
	};
	return type1;
}

enum TYPE prs_relational_expr(FILE *fp, int mode) {
	enum TYPE type1, type2;

	type1 = prs_simple_expr(fp, mode);
	if (isRelationalOperator(token.kind)) {
		type2 = prs_simple_expr(fp, mode);
		if (!(type1 == type2 || ((type1 == TV || type1 == TVD || type1 == TNULL
				|| type1 == TEMPTY) && (type2 == TV || type2 == TVD || type2
				== TNULL || type2 == TEMPTY)) || ((type1 == TTS || type1
				== TNULL || type1 == TEMPTY || type1 == TINT) && (type2 == TTS
				|| type2 == TNULL || type2 == TEMPTY || type2 == TINT)))) semantic_error(
				"type mismatch.");
		type1 = TBOOL;
	};
	return type1;
}

enum TYPE prs_simple_expr(FILE *fp, int mode) {
	enum TYPE type1, type2;

	type1 = prs_term(fp, mode);
	while (isAdditiveOperator(token.kind)) {
		type2 = prs_term(fp, mode);
		if (type1 != type2 || type1 != TINT) semantic_error("type mismatch.");
	};
	return type1;
}

enum TYPE prs_term(FILE *fp, int mode) {
	enum TYPE type1, type2;

	type1 = prs_factor(fp, mode);
	next_tokn(fp, NOCHECK);
	while (isMultiplicativeOperator(token.kind)) {
		type2 = prs_factor(fp, mode);
		if (type1 != type2 || type1 != TINT) semantic_error("type mismatch.");
		next_tokn(fp, NOCHECK);
	};
	return type1;
}

enum TYPE prs_factor(FILE *fp, int mode) {
	VTYPE *v;
	enum TYPE type;

	next_tokn(fp, NOCHECK);
	switch (token.kind) {
	case SIDENTIFIER:
		if ((v = search_variable(token.id)) == NULL) semantic_error(
				"undeclared variable.");
		if (v->type != TINTARRAY && v->type != TVARRAY && v->type != TTSARRAY) { // normal variable
			if (mode == SEND_MODE || mode == NORMAL_MODE) {
				if (mode == SEND_MODE && v->isHidden) semantic_error(
						"hidden variable cannot be used here.");
			} else { // Invariant，Univalence
				if (!v->isHidden) {
					next_tokn(fp, SLBRACKET);
					if (prs_expr(fp, mode) != TINT) semantic_error(
							"type mismatch.");
					if (token.kind != SRBRACKET) syntax_error("syntax error.");
				}
			}
			type = v->type;
		} else { // array variable
			if (mode == SEND_MODE && v->isHidden) semantic_error(
					"hidden variable cannot be used here.");
			next_tokn(fp, SLBRACKET);
			if (prs_expr(fp, mode) != TINT) semantic_error("type mismatch.");
			if (token.kind != SRBRACKET) syntax_error("syntax error.");
			switch (v->type) {
			case TINTARRAY:
				type = TINT;
				break;
			case TVARRAY:
				type = TV;
				break;
			case TTSARRAY:
				type = TTS;
				break;
			default:
				semantic_error("type mismatch.");
			}
		}
		break;
	case SQUESTION:
		type = TVD;
		break;
	case SFALSE:
		type = TBOOL;
		break;
	case STRUE:
		type = TBOOL;
		break;
	case SNUM:
		type = TINT;
		break;
	case SPROC_COUNT:
		type = TINT;
		break;
	case SSIZE:
		type = TINT;
		if (mode == SEND_MODE) semantic_error("SIZE cannot be used here.");
		break;
	case SNULL:
		type = TNULL;
		if (mode == SEND_MODE) semantic_error("NULL cannot be used here.");
		break;
	case SPHASE:
		type = TTS;
		break;
	case SISCOORD:
		if (mode == INV_MODE || mode == UNI_MODE) semantic_error(
				"isCoord cannot be used here.");
		type = TBOOL;
		if (!coord_flag) coord_flag = 1;
		break;
	case SCOORD:
		type = TINT;
		if (mode == SEND_MODE) semantic_error("Coord cannot be used here.");
		if (!coord_flag) coord_flag = 1;
		break;
	case SPID:
		if (mode == INV_MODE || mode == UNI_MODE) semantic_error(
				"pid cannot be used here.");
		type = TINT;
		break;
	case SVVAL:
		if (mode != UNI_MODE) semantic_error("v cannot be used here.");
		type = TV;
		break;
	case SRCV:
		if (mode == SEND_MODE || mode == INV_MODE || mode == UNI_MODE) semantic_error(
				"rcv cannot be used here.");
		next_tokn(fp, SLBRACKET);
		if (prs_expr(fp, mode) != TINT) semantic_error("type mismatch.");
		if (token.kind != SRBRACKET) syntax_error("syntax error.");
		next_tokn(fp, SDOT);
		next_tokn(fp, NOCHECK);
		if (token.kind != SIDENTIFIER && token.kind != SCOORD) syntax_error(
				"syntax error.");
		if (token.kind == SCOORD && sendCoord)
			type = TINT;
		else if (token.kind == SIDENTIFIER && (v = search_variable(token.id))
				!= NULL && v->isMessage) {
			if (v->type != TVARRAY && v->type != TTSARRAY) { // normal variable
				type = v->type;
			} else { // array variable
				semantic_error("cannot be used as message.");
			}
		} else semantic_error("cannot be used as message.");
		break;
	case SLPAREN:
		type = prs_expr(fp, mode);
		if (token.kind != SRPAREN) syntax_error("syntax error.");
		break;
	default:
		syntax_error("syntax error.");
	};
	return type;
}

int isEqualityOperator(enum SYMBOL kind) { // if '==' or '!='  then 1 else 0
	switch (kind) {
	case SEQUAL:
	case SNOTEQUAL:
		return 1;
	default:
		return 0;
	}
}

int isRelationalOperator(enum SYMBOL kind) { // if '<' or '<=' or '>' or '>='  then 1 else 0
	switch (kind) {
	case SLESS:
	case SLESSEQUAL:
	case SGREAT:
	case SGREATEQUAL:
		return 1;
	default:
		return 0;
	}
}

int isAdditiveOperator(enum SYMBOL kind) { // if '+' or '-' then 1 else 0
	switch (kind) {
	case SPLUS:
	case SMINUS:
		return 1;
	default:
		return 0;
	}
}

int isMultiplicativeOperator(enum SYMBOL kind) { // if '*' or '/' then 1 else 0
	switch (kind) {
	case SMULT:
	case SDIV:
		return 1;
	default:
		return 0;
	}
}

int isReservedKeyword(const char * name) {
	return (!strcmp(name, "dv") || !strcmp(name, "NULL") || !strcmp(name,
			"coord") || !strcmp(name, "phase") || !strcmp(name, "rcv")
			|| !strcmp(name, "N") || !strcmp(name, "size"));
}

void insert_variable(char *name, enum TYPE type, int value, int send,
		int hidden, int assign_count, int *ptr, int other_field) {
	VTYPE *newnode, *p;

	newnode = (VTYPE *) malloc(sizeof(VTYPE));
	strcpy(newnode->name, name);
	newnode->type = type;
	newnode->value = value;
	newnode->isMessage = send;
	newnode->isHidden = hidden;
	newnode->assign_count = assign_count;
	newnode->assign_count_elem = ptr;
	newnode->other_field = other_field;
	newnode->next = NULL;
	if (v_list != NULL) {
		for (p = v_list; p->next != NULL; p = p->next)
			;
		p->next = newnode;
	} else {
		v_list = newnode;
	}
}

VTYPE *search_variable(char *name) {
	VTYPE *p;

	for (p = v_list; p != NULL; p = p->next) {
		if (!strcmp(name, p->name)) break;
	}
	return p;
}

int next_tokn(FILE *fp, int kind) {
	int i;
	int result;
	int lineNumber;

	lineNumber = token.line;
	if ((result = gettokn()) != 0) {
		if (kind != NOCHECK && kind != NONE && kind != token.kind) syntax_error(
				"syntax error.");
		switch (token.kind) {
		case SEMPTY:
		case SFOREACH:
			syntax_error("syntax error.");
			break;
		}
		if (token.line != 1) {
			for (i = lineNumber; i < token.line; i++)
				fprintf(fp, "\n");
		}
		fprintf(fp, "%s ", yytext);
	} else if (kind != NONE) syntax_error("syntax error.");
	return result;
}
